const guzik = document.getElementById('guzior');

guzik.addEventListener('click', () => {
  // schowanie guziora
  guzik.style.display = 'none';

});
